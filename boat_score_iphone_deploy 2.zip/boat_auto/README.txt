BOAT SCORE iPhone Web app / Render deploy
1. Upload these files to a GitHub repository (keep at repository root).
2. Render.com -> New -> Blueprint -> select repository -> deploy (free plan).
3. Open resulting onrender.com URL in iPhone Safari -> Share -> Add to Home Screen.
Caution: HTML scraping depends on official site markup and has NOT been verified against live race data. The app rejects incomplete 6-boat extraction. Respect official site terms and avoid high-frequency access.

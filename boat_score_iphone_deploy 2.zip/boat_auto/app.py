from flask import Flask, jsonify, request, send_from_directory
from server import BASE
from bs4 import BeautifulSoup
from datetime import datetime
import requests,re,os
app=Flask(__name__,static_folder='.')
@app.get('/')
def home(): return send_from_directory('.', 'index.html')
@app.get('/api/race')
def race():
 try:
  d=request.args.get('date','');v=request.args.get('venue','');r=int(request.args.get('race','0'))
  if not re.fullmatch(r'\d{8}',d) or not re.fullmatch(r'\d{2}',v) or not 1<=int(v)<=24 or not 1<=r<=12:raise ValueError('入力値が正しくありません')
  datetime.strptime(d,'%Y%m%d')
  response=requests.get(BASE,params={'hd':d,'jcd':v,'rno':r},headers={'User-Agent':'Mozilla/5.0'},timeout=15)
  response.raise_for_status();soup=BeautifulSoup(response.content,'html.parser');boats=[]
  for group in soup.select('tbody.is-fs12'):
   tr=group.select_one('tr')
   if not tr:continue
   raw=[c.get_text(' ',strip=True) for c in tr.find_all('td',recursive=False)]
   reg=next((re.search(r'\b(\d{4})\s*/\s*(A1|A2|B1|B2)\b',x) for x in raw[:4] if re.search(r'\b(\d{4})\s*/\s*(A1|A2|B1|B2)\b',x)),None)
   if not reg:continue
   idx=next((i for i,x in enumerate(raw) if reg.group(0) in x),None)
   if idx is None or idx+4>=len(raw):continue
   st=re.search(r'(?<!\d)0\.\d{1,3}(?!\d)',raw[idx+1]);win=re.search(r'(?<!\d)\d{1,2}\.\d{1,2}(?!\d)',raw[idx+2]);motor=re.findall(r'\d{1,3}\.\d{1,2}',raw[idx+4])
   if not(st and win and motor):continue
   boats.append({'boat':len(boats)+1,'name':raw[idx].replace(reg.group(0),'').strip(),'grade':reg.group(2),'win':float(win.group()),'st':float(st.group()),'motor':float(motor[0])})
  if len(boats)!=6:raise ValueError('6艇のデータを確実に解析できません。公式ページの構造や開催日を確認してください')
  return jsonify(boats=boats,source=response.url)
 except Exception as e:return jsonify(error=str(e)),422
